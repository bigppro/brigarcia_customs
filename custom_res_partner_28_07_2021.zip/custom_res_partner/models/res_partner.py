# -*- coding: utf-8 -*-

from odoo import models, fields, api

class custom_res_partner(models.Model):
    #_name = 'res.partner'
    _inherit = 'res.partner'

    user_id = fields.Many2one('res.users','Vendedor', default=lambda self: self.env.user)
    category_id = fields.Many2many('res.partner.category', id1='partner_id', id2='category_id', default=lambda self: self.env['res.partner.category'].search([('name','=','Services')]))
#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         self.value2 = float(self.value) / 100