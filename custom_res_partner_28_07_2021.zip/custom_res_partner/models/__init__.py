# -*- coding: utf-8 -*-

from . import res_partner
from . import ncf_manager