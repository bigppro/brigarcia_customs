# -*- coding: utf-8 -*-

from odoo import models, fields, api

class custom_res_partner(models.Model):
    #_name = 'res.partner'
    _inherit = 'res.partner'

    @api.depends('is_company')
    def _get_default_fiscal(self):
        if not self.is_company:
            default_type = 'final'
        else:
            default_type = 'fiscal'
        return default_type

    sale_fiscal_type = fields.Selection([
        ("final", "Consumo"),
        ("fiscal", u"Crédito Fiscal"),
        ("gov", "Gubernamental"),
        ("special", u"Regímenes Especiales"),
        ("unico", u"Único Ingreso"),
        ("export", u"Exportaciones"),
    ],
        string="Tipo de comprobante",
        index=True,
        store=True,
        default=_get_default_fiscal,
    )
#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         self.value2 = float(self.value) / 100