To configure this module:

#. Go to 'Purchases > Configuration > Settings'.
#. In the *Orders* section you can set the *State 'Approved' in Purchase
   Orders*.
