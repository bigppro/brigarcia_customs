from odoo import models, fields, api

class ControlExpirationDateResCompany(models.Model):
    _name = 'res.company'
    _inherit = 'res.company'

    days_validity_date = fields.Integer('Dias de expiracion de cotizaciones')
