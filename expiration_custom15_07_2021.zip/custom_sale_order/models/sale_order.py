# -*- coding: utf-8 -*-

from odoo import models, fields, api

class custom_sale_order(models.Model):
    #_name = 'custom_sale_order.custom_sale_order'
    _inherit = "sale.order"
    #_rec_name ="partner_id"

    project = fields.Many2one('project.project', string="Proyecto", help="Elija el proyecto asignado para este presupuesto")
    detail = fields.Char(string='Detalle', help="Establecer un detalle breve del proyecto")

    """ @api.multi
    def _get_default_wpartner(self):
        return self.env['res.partner'].search([('parent_id.id', '=', self.partner_id.id)]) """

    contact = fields.Many2one('res.partner', string="Contacto", help="Elija el contacto asignado en la empresa", store=True)
    
    @api.model
    def _get_project_comments(self):
        return self.env.user.company_id.project_comments

    @api.model
    def _get_generals_quotation(self):
        return self.env.user.company_id.generals_quotation

    project_comments = fields.Text(default=_get_project_comments, String="Condiciones", 
    help="Indique las condiciones del proyecto/presupuesto", readonly=False)

    generals_quotation = fields.Text(default=_get_generals_quotation, String="Generales",
    help="Indique datos generales de la cotización", readonly=False)