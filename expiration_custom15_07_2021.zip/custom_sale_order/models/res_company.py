# -*- coding: utf-8 -*-

from odoo import models, fields, api

class custom_res_company_general_fields(models.Model):
    #_name = 'custom_sale_order.custom_sale_order'
    _inherit = "res.company"

    project_comments = fields.Text(String="",help="Indique las condiciones del proyecto/presupuesto. Nota: Esta información se cargará automáticamente en las cotizaciones.")
    generals_quotation = fields.Text(String="",help="Indique datos generales de la cotización. Nota: Esta información se cargará automáticamente en las cotizaciones.")