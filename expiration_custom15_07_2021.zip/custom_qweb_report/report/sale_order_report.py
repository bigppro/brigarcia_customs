from odoo import api, models
# from bahttext import bahttext
# ต้อง install bahttext lib ก่อน
# pip/pip3 install bahttext

class CustomReport(models.Model):
    _inherit = 'sale.order'

@api.multi

def print_report(self):

     return self.env.ref('custom_qweb_report.sale_order_report_template').report_action(self)
