# -*- coding: utf-8 -*-
from . import models
from . import new_state_sale
# from . import res_partner