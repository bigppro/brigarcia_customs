# -*- coding: utf-8 -*-
###############################################################################
#    License, author and contributors information in:                         #
#    __manifest__.py file at the root folder of this module.                  #
###############################################################################

from odoo import models, fields, api
from datetime import datetime, date
from dateutil import parser
from odoo.exceptions import UserError
class sale_order_states(models.Model):

    _inherit = 'sale.order'

    state = fields.Selection([
        ('draft', 'Quotation'),
        ('sent', 'Quotation Sent'),
        ('negotiation', 'Negociacion'),
        ('sale', 'Sale Order'),
        ('done', 'Done'),
        ('cancel', 'Cancelled'),
        ('expired', 'Expirada'),
        ('replaced', 'Sustituida'),
        ('lost', 'Perdida'),
        ('blocked', 'Bloqueada'),
        ('waiting_for_approval', 'Esperando aprobación'),
        ], string='Status', readonly=True, copy=False, index=True, track_visibility='onchange', default='draft')
    
    lost_id = fields.Many2one(
        string=u'Cambio del estado',
        comodel_name='state_sale.lost',
        ondelete='set null',
        help="Formulario donde se indica la razon por el cual se cambio el estado a la cotizacion",
    )

    reason_name = fields.Many2one(string=u'Razon del estado',  comodel_name='state_sale.lost_reason',
    related='lost_id.lost_reason_id', help="Nombre de la razon de la que por que se cambio al estado actuar", 
    store=True
    )

    substitute_order_id = fields.Many2one(
        string=u'Sustituida por',
        comodel_name='sale.order',
        ondelete='set null',
    )

    in_negotiation = fields.Boolean(
        string=u'En negociacion',
        default=False
    )

    
    expired_date = fields.Date(
        string=u'Fecha de Expiracion',
        default=False,
    )
    

    @api.multi
    def view_state_reason(self, reason_type ):

        state_lost_view = self.env['ir.model.data'].xmlid_to_res_id('state_sale.view_quoantation_state_lost_form')

        res = {
                'name': '¿Desea cambiar el estado de la cotizacion? Por favor espeficique las razones',
                'type': 'ir.actions.act_window',
                'view_type': 'form',
                'view_mode': 'form',
                'res_model': 'state_sale.lost',
                'view_id': state_lost_view,
                'target': 'new',
                'flags': {'action_buttons': False},
                'context': {'default_sale_order_id': self.id,
                            'default_lost_type': reason_type}

            }
        return res


 
    @api.multi
    def action_replaced(self):
        return self.view_state_reason('replaced')
        
  
    @api.multi
    def action_cancelar(self):
        return self.view_state_reason('cancel')

    @api.multi
    def action_lost(self):
        return self.view_state_reason('lost')


    @api.multi
    def action_negotiation(self):
        if self.in_negotiation == False:
            if self.validity_date:
                return self.view_state_reason('negotiation')
            else:
                raise UserError("Debe de indiciar la Fecha de Expiración de esta order, para poder indicicar que se esta negociando")


    @api.multi
    def action_block(self):
        return self.view_state_reason('blocked')
        
    @api.multi
    def action_unblock(self):
        self.write({'state':'draft'})
             
 
    @api.multi
    def check_expired_order(self):
        # Esta funcion tiene que ser llamada solo por factura expiradas
        # Esta se tomaran en cuenta para el credito, si su expiracion fue hace mas de 10 dias
        if self.expired_date:
            date = parser.parse(self.expired_date)
            actual_date = datetime.now()
            days_since_expiration = (actual_date - date).days 
            if days_since_expiration < 11:
                return False
        return True

    @api.model
    def automated_action_expired_method(self):
        records = self.search([('validity_date','!=',False),('state','in',('draft','sent','negotiation','waiting_for_approval'))])
    
        for record in records:
            """  curren_validity_date = (record.validity_date)
            curren_validity_date = curren_validity_date.date()
            actual_date = datetime.today() 
            """

            if record.validity_date < date.today():
                record.write({'state': 'expired','expired_date': fields.Date.today()})

         

