# -*- coding: utf-8 -*-

from odoo import models, fields, api
from datetime import timedelta
from dateutil import parser

class SaleStateReason(models.Model):
    _name = 'state_sale.lost_reason'

    name = fields.Char('Nombre')

    reason_type = fields.Selection(
        string=u'Tipo',
        selection=[('lost', 'Perdida'), ('cancel', 'Cancelada'),
        ('replaced', 'Sustituida'), ('negotiation', 'Negociacion'),('blocked', 'Bloqueada'),('all', 'Todos')],
        help=u'Indica en que tipo de cambio de estado, se podra selecionar esta razón',
        default='lost',
        
    )
    description = fields.Text('Descripcion',help=u'Descripcion opcional de porque se creo esta razón')


class StateSaleLost(models.Model):
    _name = 'state_sale.lost'


    name = fields.Char('Numero',default="Borrador")

    user_id = fields.Many2one('res.users', string='Usuario',default=lambda self: self.env.user)

    responsable_id = fields.Many2one('res.users', string="Responsable")

    followers_id = fields.Many2many('res.users', string="Seguidores") #followers user

    comment = fields.Text(
        string=u'Comentario',
    )

    
    lost_type = fields.Selection(
        string=u'Tipo',
        selection=[('lost', 'Perdida'), ('cancel', 'Cancelada'),
        ('replaced', 'Sustituida'), ('negotiation', 'Negociacion'),('blocked', 'Bloqueada')],
        default='lost',
        help='Indica por que se esta registrando esta cotizacion, por una perdida o por una cancelacion'
    )
    
    
    sale_order_id = fields.Many2one(
        string=u'Cotizacion/Pedido',
        comodel_name='sale.order',
    )
    
    lost_reason_id = fields.Many2one(
        string=u'Razon del estado',
        comodel_name='state_sale.lost_reason',
        required=True,
        
    )


    substitute_order_id = fields.Many2one(
        string=u'Sustituida por',
        comodel_name='sale.order',
        ondelete='set null',
    )


    @api.multi
    def lost_state(self):
        self.sale_order_id.write({'state': 'lost','lost_id':self.id})

    @api.multi
    def replace_state(self):
        self.sale_order_id.write({'state': 'replaced','substitute_order_id': self.substitute_order_id.id,'lost_id':self.id })
        
    @api.multi
    def cancel_state(self):
        self.sale_order_id.write({'lost_id':self.id})
        self.sale_order_id.action_cancel()

    @api.multi
    def negotiation_state(self):
        new_date = parser.parse(self.sale_order_id.validity_date) + timedelta(days=30)
        self.sale_order_id.validity_date = new_date.strftime("%Y-%m-%d")
        self.sale_order_id.in_negotiation = True
        self.sale_order_id.write({'state': 'negotiation','lost_id':self.id})

  
    def notify_followers(self):
        template = self.env.ref('state_sale.state_lost_email_template')

        # Send out the e-mail template to the responsables
        self.env['mail.template'].browse(template.id).send_mail(self.id)

    @api.multi
    def block_state(self):
        self.sale_order_id.write({'state': 'blocked','lost_id':self.id})

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('state_sale.lost') or 'PER'

        if 'lost_type' in vals and 'sale_order_id' in vals:
            sale = self.env['sale.order'].browse(vals['sale_order_id'])

            if vals['lost_type'] == 'lost':
                sale.write({'state': 'lost','lost_id':self.id})
            elif vals['lost_type'] == 'replaced':
                sale.write({'state': 'replaced','lost_id':self.id,'substitute_order_id': vals['substitute_order_id']})
            else:
                sale.write({'state': 'cancel','lost_id':self.id})
                sale.action_cancel()

        return super(StateSaleLost, self).create(vals)


    @api.multi 
    def change_state_quotation(self):
        if self.lost_type == 'lost':
            self.lost_state()

        elif self.lost_type == 'replaced':
            self.replace_state()

        elif self.lost_type == 'negotiation':
            self.negotiation_state()

        elif self.lost_type == 'blocked':
            self.block_state()

        else:
            self.cancel_state()

        if self.responsable_id:
            self.notify_followers()
            
    # This method if the email template
    @api.model
    def emails_of_responsable(self):
        emails = []
        for user in self.followers_id:
            if user.email:
                emails.append(user.email)

        if self.responsable_id:
            if self.responsable_id.email:
                emails.append( self.responsable_id.email)



        return ','.join(emails)

    @api.model
    def name_reason_type(self):
        # import ipdb; ipdb.set_trace()
        name = ''
        for select in self._fields['lost_type'].selection:
            if select[0]==self.lost_type:
                name  = select[1]
                break
        return name

    
