# -*- coding: utf-8 -*-
from odoo import http

# class StateSale(http.Controller):
#     @http.route('/state_sale/state_sale/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/state_sale/state_sale/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('state_sale.listing', {
#             'root': '/state_sale/state_sale',
#             'objects': http.request.env['state_sale.state_sale'].search([]),
#         })

#     @http.route('/state_sale/state_sale/objects/<model("state_sale.state_sale"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('state_sale.object', {
#             'object': obj
#         })