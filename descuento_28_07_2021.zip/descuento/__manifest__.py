{
'name': "Descuentos",
'description' : "Maneja descuentos",
'version' : "12.0.0.1",
'author' : "odoo",
'depends' : ['account', 'sale'],
'data': ['views/sale_order_view.xml',
         'views/account_invoice_view.xml',
         'views/partner_category_view.xml'],
'installable' : True,
}
