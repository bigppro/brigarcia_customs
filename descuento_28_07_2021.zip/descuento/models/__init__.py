# -*- coding: utf-8 -*-
from . import sale_order
from . import res_partner_category
from . import account_invoice