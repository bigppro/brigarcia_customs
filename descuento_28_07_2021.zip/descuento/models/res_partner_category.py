from odoo import models,fields, api


class ResPartnerCategory(models.Model):

    _inherit = 'res.partner.category'

    max_discount = fields.Float('Descuento maximo')


